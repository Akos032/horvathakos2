import 'bootstrap/dist/css/bootstrap.min.css'
import React, {useEffect,useState} from 'react'
import 'tachyons'
import axios from "axios"

export const Szobak = () => {
    const [data,setData] = useState([])
    return(
        <>
        <div>
            <h1>Hi</h1>
        </div>
        </>
    )
}